Keyward Vault - Setup
=====================

1. Copy this whole folder onto your Vault VM (or cloud Windows instance).
2. Right-click Setup.exe and choose "Run as administrator".
   (If Windows SmartScreen warns, click "More info" then "Run anyway" - it is
    unsigned because it is your own lab build.)
3. Follow the wizard. Accept the defaults for a standalone lab install, and set
   a Master and Administrator password at the end.
4. When it finishes, open "Keyward Server Central Administration" (in the install
   folder, Server\KeywardServerAdmin.exe) to watch the Vault run.

Silent install (optional, from an elevated Command Prompt):
   Setup.exe --silent name="Hasan" company="Keyward Lab" master="Str0ng!" admin="Str0ng!"

Uninstall:
   Setup.exe --uninstall

Built by M. Hasan Zafar.
